﻿
using var game = new MemoryGame.Game1();
game.Run();
