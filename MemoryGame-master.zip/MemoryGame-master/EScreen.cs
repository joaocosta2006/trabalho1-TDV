public enum EScreen
{
  MENU,
  GAME
}