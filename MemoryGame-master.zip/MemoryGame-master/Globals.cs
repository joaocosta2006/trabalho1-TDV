using MemoryGame;

public static class Globals
{
  public static Game1 GAME_INSTANCE;
  public static int SCREEN_WIDTH;
  public static int SCREEN_HEIGHT;
}